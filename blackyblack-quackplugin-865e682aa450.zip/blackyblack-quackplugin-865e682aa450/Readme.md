#Quack NXT Plugin

##Version

1.4

##Description

Atomic asset swap plugin for NXT wallet.

##Usage

Click Create button to create new swap request (Quack). Click Scan button to check Quacks history.

##Installation

Unzip into [NRS installation directory]/html/ui/plugins. Make sure plugins are allowed in NXT wallet settings.

##Compatibility

NRS 1.7.x

##Security

###Hash

064f36a459515321f2d7452419ca5b052448c2f048c7065bca21c81319778597 *quack-1.4.zip

###Token

4avn6us1bo1601otsnet7gqc4uvok2sgf27i0l9ii3knr0741bnmihp61ipalg0458bon1a7ranf75lpgcehq609dlhjkcuqnmvvviql45d0t8244n3cung4i3lq5ncbuunhh3m84e7qkakkupsd9t2lar4p9had